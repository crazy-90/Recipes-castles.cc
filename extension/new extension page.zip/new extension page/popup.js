document.addEventListener('DOMContentLoaded', async () => {
  const ROW_HEIGHT = 36;
  const INITIAL_SEARCH_HEIGHT = 150;

  const resp = await fetch('recipes.json');
  const recipes = await resp.json();

  const searchInput = document.getElementById('search');
  const results = document.getElementById('results');
  const searchContainer = document.getElementById('searchContainer');
  const viewer = document.getElementById('viewer');
  const frame = document.getElementById('recipeFrame');
  const backBtn = document.getElementById('backBtn');
  const viewerBtns = document.getElementById('viewerBtns');
  const themeBtn = document.getElementById('themeBtn');
  const favListBtn = document.getElementById('favListBtn');
  const recentBtn = document.getElementById('recentBtn');
  const toggleBtn = document.getElementById('toggleBtn'); // ✅ Toggle link button

  // Mines elements
  const minesOverlay = document.getElementById('minesOverlay');
  const minesContent = document.getElementById('minesContent');
  const mineToggleBtn = document.getElementById('mineToggleBtn'); 
  const mineBackBtn = document.getElementById('mineBackBtn');

  const storageAvailable = typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;
  const storageGet = async (key) => storageAvailable
    ? new Promise(r => chrome.storage.local.get(key, res => r(res[key])))
    : JSON.parse(localStorage.getItem(key) || 'null');
  const storageSet = async (key, value) => storageAvailable
    ? new Promise(r => chrome.storage.local.set({ [key]: value }, r))
    : localStorage.setItem(key, JSON.stringify(value));

  let favorites = await storageGet('favorites') || [];
  let recent = await storageGet('recent') || [];
  let theme = await storageGet('theme') || 'light';
  let currentRecipe = null, currentLinkIndex = 0;

  document.documentElement.setAttribute('data-theme', theme);
  themeBtn.textContent = theme === 'dark' ? '🌙' : '🌓';

  const saveFavorites = () => storageSet('favorites', favorites);
  const saveRecent = () => storageSet('recent', recent);
  const saveTheme = () => storageSet('theme', theme);

  const escapeRegExp = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  const buildItem = (recipe, highlightText) => {
    const li = document.createElement('li');
    li.className = 'resultItem';
    const nameWrap = document.createElement('div');
    nameWrap.className = 'recipeName';
    const re = new RegExp(escapeRegExp(highlightText || ''), 'ig');
    nameWrap.innerHTML = highlightText
      ? recipe.name.replace(re, m => `<mark>${m}</mark>`)
      : recipe.name;

    const star = document.createElement('button');
    star.className = 'starBtn';
    if (favorites.includes(recipe.name)) star.classList.add('active');
    star.innerHTML = '★';
    star.addEventListener('click', e => {
      e.stopPropagation();
      const idx = favorites.indexOf(recipe.name);
      if (idx === -1) {
        favorites.push(recipe.name);
        star.classList.add('active');
      } else {
        favorites.splice(idx, 1);
        star.classList.remove('active');
      }
      saveFavorites();
    });

    li.append(nameWrap, star);
    li.addEventListener('click', () => openRecipe(recipe));
    return li;
  };

  const renderResults = (query = '', focusSection = null) => {
    results.innerHTML = '';
    const q = query.trim().toLowerCase();
    let list = recipes;

    if (focusSection === 'favorites') {
      list = recipes.filter(r => favorites.includes(r.name));
    } else if (focusSection === 'recent') {
      list = recipes.filter(r => recent.includes(r.name));
    } else if (q) {
      list = recipes.filter(r => r.name.toLowerCase().includes(q));
    }

    if (list.length === 0) {
      results.classList.remove('show');
      results.style.display = 'none';
      document.body.style.height = `${INITIAL_SEARCH_HEIGHT}px`;
      return;
    }

    list.forEach(r => results.appendChild(buildItem(r, q)));
    results.classList.add('show');
    results.style.display = 'block';
    const totalRows = results.querySelectorAll('li.resultItem').length;
    document.body.style.height = `${Math.min(ROW_HEIGHT * totalRows + 150, 475)}px`;
  };

  const openRecipe = recipe => {
    currentRecipe = recipe;
    currentLinkIndex = 0;
    frame.src = recipe.links[currentLinkIndex];
    viewer.style.display = 'flex';
    viewerBtns.style.display = 'flex';
    searchContainer.style.display = 'none';
    minesOverlay.style.display = 'none'; // hide mines if open
    document.body.style.height = '740px';

    recent = [recipe.name, ...recent.filter(n => n !== recipe.name)].slice(0, 5);
    saveRecent();
  };

  backBtn.addEventListener('click', () => {
  viewer.style.display = 'none';
  viewerBtns.style.display = 'none';
  searchContainer.style.display = 'flex'; // show search container
  searchInput.style.display = 'block';    // show search input
  results.style.display = 'block';        // show results if any
  mineToggleBtn.style.display = 'inline-block'; // show Mines button
  document.body.style.height = '250px';   // bigger default
});


  themeBtn.addEventListener('click', () => {
    theme = theme === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', theme);
    themeBtn.textContent = theme === 'dark' ? '🌙' : '🌓';
    saveTheme();
  });

  favListBtn.addEventListener('click', () => renderResults('', 'favorites'));
  recentBtn.addEventListener('click', () => renderResults('', 'recent'));
  searchInput.addEventListener('input', e => renderResults(e.target.value));

  // ✅ Toggle link button
  toggleBtn.addEventListener('click', () => {
    if (!currentRecipe) return;
    currentLinkIndex = (currentLinkIndex + 1) % currentRecipe.links.length;
    frame.src = currentRecipe.links[currentLinkIndex];
  });

  // ✅ Mines overlay
  const mineData = {
    "Tropical Mine": ["Tropical Grass", "Mountain", "Sand", "Half Sand", "Water", "Coral", "Lava", "Soil", "Dirt", "Ruby", "Rubber Tree", "Palm Tree", "Cotton Bush", "Bush", "Fern", "Fairy Dust", "Flowers", "Sugarcane"],
    "Forest Mine": ["Grass", "Water", "Mud", "Dirt", "Tree", "Sunberry Bushes", "Bushes", "Lilypads", "Flowers", "Stone", "Coal", "Iron", "Silver", "Beeswax", "Honey", "Fairy Dust", "Gold"],
    "Desert Mine": ["Boulders", "Mesa Top", "Mesa", "Tropical Grass*", "Water*", "Mud*", "Sand", "Dirt", "Cactus", "Palm Trees*", "Chiliberry Bushes", "Eggs", "Stone", "Gold", "Silver", "Iron", "Coal", "Bones", "Sticks"],
    "Mountain Mine": ["Snow", "Mountain Boulders", "Ice", "Mountain", "Mountain Grass", "Cave Wall", "Pine Trees", "Yumberry Bushes", "Eggs", "Stone", "Coal", "Iron", "Silver", "Beeswax", "Honey", "Gold", "Sticks"],
    "Arctic Mine": ["Ice Boulders", "Mountain Boulders", "Snow", "Oil", "Mountain", "Mountain Grass", "Ice", "Dirt", "Dead Trees", "Snowy Pine Trees", "Frostberries", "Fast Geysers", "Slow Geysers", "Coal", "Iron", "Silver", "Gold", "Sticks"]
  };

  // Mines overlay
mineToggleBtn.addEventListener('click', () => {
  minesContent.innerHTML = '';

  Object.entries(mineData).forEach(([mineName, items]) => {
    const header = document.createElement('div');
    header.className = 'sectionHeader';
    header.textContent = mineName;

    const ul = document.createElement('ul');
    ul.style.display = 'none';
    ul.style.listStyle = 'none';
    ul.style.paddingLeft = '10px';

    // ✅ Make each mine item clickable
    items.forEach(itemName => {
      const li = document.createElement('li');
      li.textContent = itemName;
      li.className = 'resultItem';

      li.addEventListener('click', () => {
        const cleanName = itemName.replace(/\*$/, '').trim(); // remove trailing * if any
        const recipe = recipes.find(r => r.name.toLowerCase() === cleanName.toLowerCase());
        if (recipe) {
          minesOverlay.style.display = 'none';
          mineBackBtn.style.display = 'none';
          openRecipe(recipe);
        } else {
          console.warn(`Recipe not found: "${cleanName}"`);
        }
      });

      ul.appendChild(li);
    });

    header.addEventListener('click', () => {
      ul.style.display = ul.style.display === 'none' ? 'block' : 'none';
    });

    minesContent.appendChild(header);
    minesContent.appendChild(ul);
  });

  // Show overlay
  minesOverlay.style.display = 'flex';
  mineToggleBtn.style.display = 'none';
  mineBackBtn.style.display = 'inline-block';
  searchInput.style.display = 'none';
  results.style.display = 'none';
  document.body.style.height = '450px';
});


mineBackBtn.addEventListener('click', () => {
  minesOverlay.style.display = 'none';
  mineBackBtn.style.display = 'none';
  mineToggleBtn.style.display = 'inline-block';
  searchInput.style.display = 'block';
  results.style.display = 'block';
  document.body.style.height = '250px'; // match new default
});



  document.body.style.height = '250px';
});
