import json

# --- File paths ---
input_file = "recipes.json"
output_file = "recipes_categorized.json"

# --- Define your mine category keywords ---
mine_categories = {
    "Tropical Mine": [
        "Tropical Grass", "Mountain", "Sand", "Half Sand", "Water", "Coral", "Lava",
        "Soil", "Dirt", "Ruby", "Rubber Tree", "Palm Tree", "Cotton Bush", "Bush",
        "Fern", "Fairy Dust", "Flowers", "Sugarcane"
    ],
    "Forest Mine": [
        "Grass", "Water", "Mud", "Dirt", "Tree", "Sunberry Bush", "Bush",
        "Lily Pad", "Flower", "Stone", "Coal", "Iron", "Silver", "Beeswax",
        "Honey", "Fairy Dust", "Gold"
    ],
    "Desert Mine": [
        "Boulder", "Mesa Top", "Mesa", "Tropical Grass", "Water", "Mud", "Sand",
        "Dirt", "Cactus", "Palm Tree", "Chiliberry Bush", "Egg", "Stone", "Gold",
        "Silver", "Iron", "Coal", "Bone", "Stick"
    ],
    "Mountain Mine": [
        "Snow", "Mountain Boulder", "Ice", "Mountain", "Mountain Grass", "Cave Wall",
        "Pine Tree", "Yumberry Bush", "Egg", "Stone", "Coal", "Iron", "Silver",
        "Beeswax", "Honey", "Gold", "Stick"
    ],
    "Arctic Mine": [
        "Ice Boulder", "Mountain Boulder", "Snow", "Oil", "Mountain", "Mountain Grass",
        "Ice", "Dirt", "Dead Tree", "Snowy Pine Tree", "Frostberry Bush", "Fast Geyser",
        "Slow Geyser", "Coal", "Iron", "Silver", "Gold", "Stick"
    ]
}

# --- Load existing data ---
with open(input_file, "r", encoding="utf-8") as f:
    recipes = json.load(f)

# --- Exact match categorization ---
for recipe in recipes:
    name = recipe["name"].strip()
    categories = set(recipe.get("categories", []))

    for mine_name, keywords in mine_categories.items():
        for keyword in keywords:
            if name.lower() == keyword.lower():  # ✅ Exact match only
                categories.add(mine_name)

    recipe["categories"] = sorted(categories)

# --- Save updated JSON ---
with open(output_file, "w", encoding="utf-8") as f:
    json.dump(recipes, f, indent=2, ensure_ascii=False)

print(f"✅ Categorization complete! Exact matches only. Saved as {output_file}")
