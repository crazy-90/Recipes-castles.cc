import json

input_file = "recipes_categorized.json"
output_file = "recipes_categorized_clean.json"

# Load JSON file
with open(input_file, "r", encoding="utf-8") as f:
    data = json.load(f)

# Process each entry to remove duplicate categories
for entry in data:
    if "categories" in entry:
        entry["categories"] = sorted(set(entry["categories"]))

# Save cleaned version
with open(output_file, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=2, ensure_ascii=False)

print(f"✅ Cleaned categories and saved to {output_file}")
