import fs from "fs";

const FILE_PATH = "./Community_prices.json";
const OUTPUT_PATH = "./Community_prices_clean.json";

// Load and parse the JSON file
const data = JSON.parse(fs.readFileSync(FILE_PATH, "utf8"));

// Define keywords to remove
const removeKeywords = ["snowy", "crazy"];

// Filter out objects that match
const cleaned = data.filter(item => {
  if (!item.words || !Array.isArray(item.words)) return true;

  // Check each string in "words"
  return !item.words.some(wordStr =>
    removeKeywords.some(keyword =>
      wordStr.toLowerCase().includes(keyword.toLowerCase())
    )
  );
});

// Save new file
fs.writeFileSync(OUTPUT_PATH, JSON.stringify(cleaned, null, 2), "utf8");

console.log(`✅ Cleaned file saved as ${OUTPUT_PATH}`);
console.log(`Removed ${data.length - cleaned.length} entries.`);
