document.addEventListener('DOMContentLoaded', async () => {
  const ROW_HEIGHT = 36;
  const INITIAL_SEARCH_HEIGHT = 150;

  const resp = await fetch('recipes.json');
  const recipes = await resp.json();

  const searchInput = document.getElementById('search');
  const results = document.getElementById('results');
  const searchContainer = document.getElementById('searchContainer');
  const viewer = document.getElementById('viewer');
  const frame = document.getElementById('recipeFrame');
  const backBtn = document.getElementById('backBtn');
  const viewerBtns = document.getElementById('viewerBtns');
  const themeBtn = document.getElementById('themeBtn');
  const favListBtn = document.getElementById('favListBtn');
  const recentBtn = document.getElementById('recentBtn');
  const toggleBtn = document.getElementById('toggleBtn'); // ✅ Toggle link button
/* =======================
   PRICE TRACKER — ROW LOCK + PENCIL + AUTO BLANK ROW + SAVE + SELECT
   ======================= */
(() => {
  // --- Main Overlay ---
  const priceTrackerOverlay = document.createElement("div");
  priceTrackerOverlay.id = "priceTrackerOverlay";
  priceTrackerOverlay.style = `
    display:none;
    flex-direction:column;
    align-items:flex-start;
    padding:10px;
    background:var(--panel);
    overflow-y:auto;
    border-top:1px solid rgba(0,0,0,0.1);
    width:95%;
    height:450px;
  `;
  document.body.appendChild(priceTrackerOverlay);

  // Top Control Row
  const controlRow = document.createElement("div");
  controlRow.style = "display:flex; gap:6px; margin-bottom:10px; width:100%;";
  priceTrackerOverlay.appendChild(controlRow);

  // Back Button
  const ptBackBtn = document.createElement("button");
  ptBackBtn.textContent = "⬅️ Back";
  ptBackBtn.style = `
    flex:1;
    background:#4a90e2;
    color:#fff;
    font-weight:bold;
    padding:4px 6px;
    border:none;
    border-radius:6px;
    cursor:pointer;
  `;
  controlRow.appendChild(ptBackBtn);

  // Save Button
  const ptSave = document.createElement("button");
  ptSave.textContent = "Save";
  ptSave.style = `
    flex:1;
    background:#4a90e2;
    color:#fff;
    font-weight:bold;
    padding:4px 6px;
    border:none;
    border-radius:6px;
    cursor:pointer;
  `;
  controlRow.appendChild(ptSave);

  // Clear Button
  const ptClear = document.createElement("button");
  ptClear.textContent = "Clear";
  ptClear.style = `
    flex:1;
    background:#e24a4a;
    color:#fff;
    font-weight:bold;
    padding:4px 6px;
    border:none;
    border-radius:6px;
    cursor:pointer;
    display: none;
    user-select: none;
  `;
  controlRow.appendChild(ptClear);

  // Remove Selected Button (NEW)
  const ptRemoveSelected = document.createElement("button");
  ptRemoveSelected.textContent = "Remove Selected";
  ptRemoveSelected.style = `
    flex:1;
    background:#ff9f00;
    color:#fff;
    font-weight:bold;
    padding:4px 6px;
    border:none;
    border-radius:6px;
    cursor:pointer;
  `;
  controlRow.appendChild(ptRemoveSelected);

  // Title
  const ptTitle = document.createElement("h3");
  ptTitle.textContent = "Price Tracker";
  ptTitle.style = "margin:0 0 10px 0;font-weight:bold;";
  priceTrackerOverlay.appendChild(ptTitle);

  // Total profit display
  const totalRow = document.createElement("div");
  totalRow.style = "width:100%; display:flex; justify-content:flex-end; align-items:center; margin-bottom:6px; font-weight:bold;";
  const totalLabel = document.createElement("div");
  totalLabel.textContent = "Total: ";
  totalLabel.style = "margin-right:8px;";
  const totalValue = document.createElement("div");
  totalValue.textContent = "";
  totalRow.append(totalLabel, totalValue);
  priceTrackerOverlay.appendChild(totalRow);

  // Row container for main overlay
  const rowContainer = document.createElement("div");
  rowContainer.style = "display:flex; flex-direction:column; gap:6px; width:100%;";
  priceTrackerOverlay.appendChild(rowContainer);

  const STORAGE_KEY = "priceTrackerRows";

  // ---------- helpers ----------
  function profitText(boughtStr, soldStr) {
    const b = Number(boughtStr);
    const s = Number(soldStr);
    const bIsNum = !isNaN(b) && String(boughtStr).trim() !== "";
    const sIsNum = !isNaN(s) && String(soldStr).trim() !== "";
    if (!bIsNum && !sIsNum) return "";
    const profit = (sIsNum ? s : 0) - (bIsNum ? b : 0);
    if (!sIsNum) return "";
    return `Profit: ${profit > 0 ? "+" : ""}${profit}`;
  }

  function recomputeTotal(container = rowContainer) {
    const rows = [...container.children];
    let total = 0;
    rows.forEach(r => {
      const inputs = r.querySelectorAll("input");
      if (!inputs || inputs.length < 3) return;
      const bStr = inputs[1].value.trim();
      const sStr = inputs[2].value.trim();
      if (sStr === "" || Number(sStr) === 0) return;
      const b = Number(bStr) || 0;
      const s = Number(sStr) || 0;
      total += (s - b);
    });
    totalValue.textContent = total === 0 ? "" : `${total > 0 ? "+" : ""}${total}`;
  }

  // ---------- row creation ----------
  function lockRow(row) {
    const inputs = row.querySelectorAll("input");
    const display = document.createElement("div");
    display.className = "locked-display";
    display.style = `
      padding:2px 4px;
      background:#00000015;
      border-radius:4px;
      font-weight:bold;
      white-space:nowrap;
    `;
    const item = inputs[0].value.trim();
    const bought = inputs[1].value.trim();
    const sold = inputs[2].value.trim();
    let text = item;
    if (bought) text += ` | Bought: ${bought}`;
    if (sold) text += ` | Sold: ${sold}`;
    display.textContent = text;
    inputs.forEach(i => { i.style.display = "none"; i.readOnly = true; });
    const old = row.querySelector(".locked-display");
    if (old) old.remove();
    row.appendChild(display);
    const pencil = row.querySelector(".row-edit-btn");
    if (pencil) pencil.style.display = "inline-block";
    row.dataset.locked = "true";
  }

  function unlockRow(row) {
    const inputs = row.querySelectorAll("input");
    inputs.forEach(i => { i.style.display = "block"; i.readOnly = false; });
    const display = row.querySelector(".locked-display");
    if (display) display.remove();
    const pencil = row.querySelector(".row-edit-btn");
    if (pencil) pencil.style.display = "none";
    row.dataset.locked = "false";
    const first = inputs[0];
    if (first) first.focus();
  }

  function createRow(item = "", bought = "", sold = "", container = rowContainer) {
    const row = document.createElement("section");
    row.style = `
      display:flex;
      flex-direction:column;
      gap:2px;
      width:100%;
      padding:2px 4px;
      border-radius:4px;
      border:1px solid #4a90e2;
      background:#ffffff10;
      font-size:12px;
    `;
    row.classList.add("price-row");
	// Auto-save on Enter for all inputs in the price tracker
document.querySelector('#priceTrackerOverlay').addEventListener('keydown', function(e) {
  if (e.key === 'Enter' && e.target.tagName === 'INPUT') {
    e.preventDefault();   // prevent default Enter behavior
    window._priceTracker.save(); // auto-save using your existing save function
  }
});


    // inputs row
    const inputsRow = document.createElement("div");
    inputsRow.style = "display:flex; gap:4px; width:100%; align-items:center;";
    const itemInput = document.createElement("input");
    itemInput.placeholder = "Item";
    itemInput.value = item;
    itemInput.style = "flex:2; padding:2px; min-width:40px; font-size:12px;";
    const boughtInput = document.createElement("input");
    boughtInput.placeholder = "Bought";
    boughtInput.value = bought;
    boughtInput.type = "text";
    boughtInput.style = "flex:1; padding:2px; min-width:40px; font-size:12px;";
    const soldInput = document.createElement("input");
    soldInput.placeholder = "Sold";
    soldInput.value = sold;
    soldInput.type = "text";
    soldInput.style = "flex:1; padding:2px; min-width:40px; font-size:12px;";
    inputsRow.append(itemInput, boughtInput, soldInput);

    // profit + pencil
    const profitContainer = document.createElement("div");
    profitContainer.style = "display:flex; align-items:center; gap:4px; color:green; font-weight:bold; justify-content:flex-end; width:100%;";
    const profitDisplay = document.createElement("p");
    profitDisplay.style = "margin:0; white-space:nowrap;";
    profitDisplay.textContent = profitText(bought, sold);
    const pencilBtn = document.createElement("button");
    pencilBtn.className = "row-edit-btn";
    pencilBtn.title = "Edit row";
    pencilBtn.textContent = "✏️";
    pencilBtn.style = "display:none; background:transparent; border:none; cursor:pointer; padding:1px; font-size:12px;";
    pencilBtn.addEventListener("click", e => { e.stopPropagation(); unlockRow(row); });
    profitContainer.append(profitDisplay, pencilBtn);

    row.append(inputsRow, profitContainer);
    container.appendChild(row);

    // row selection
    row.addEventListener("click", e => {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      row.classList.toggle("selected-row");
    });

    // update profit & trailing blank
    function updateAll() {
      profitDisplay.textContent = profitText(boughtInput.value, soldInput.value);
      recomputeTotal();
      if (container === rowContainer) ensureTrailingBlank(container);
    }

    function handleEnterLock(e) {
      if (e.key === "Enter") {
        e.preventDefault();
        lockRow(row);
        if (container === rowContainer) ensureTrailingBlank(container);
      }
    }

    [itemInput, boughtInput, soldInput].forEach(inp => {
      inp.addEventListener("input", updateAll);
      inp.addEventListener("keydown", handleEnterLock);
    });

    // auto-lock if has initial data
    if ([item, bought, sold].some(v => v.trim() !== "")) lockRow(row);

    return row;
  }

  function ensureTrailingBlank(container) {
    const rows = [...container.children];
    const last = rows[rows.length - 1];
    if (!last) { createRow("", "", "", container); return; }
    const inputs = last.querySelectorAll("input");
    const allEmpty = [...inputs].every(i => i.value.trim() === "");
    if (!allEmpty) createRow("", "", "", container);
  }

function saveRows() {
  const rows = [...rowContainer.children];
  const data = rows.map(r => {
    const inputs = [...r.querySelectorAll("input")];
    return {
      item: inputs[0].value,
      bought: inputs[1].value,
      sold: inputs[2].value
    };
  }).filter(r => r.item || r.bought || r.sold);

  chrome.storage.local.set({ [STORAGE_KEY]: data }, () => {
    ptSave.textContent = "Saved ✓";
    setTimeout(() => (ptSave.textContent = "Save"), 900);
  });
}



function loadRows() {
  chrome.storage.local.get([STORAGE_KEY], result => {
    const data = result[STORAGE_KEY] || [];

    rowContainer.innerHTML = "";

    data.forEach(d =>
      createRow(d.item, d.bought, d.sold, rowContainer)
    );

    ensureTrailingBlank(rowContainer);
    recomputeTotal();
  });
}



function clearAll() {
  chrome.storage.local.remove(STORAGE_KEY, () => {
    rowContainer.innerHTML = "";
    createRow("", "", "", rowContainer);
    recomputeTotal();
  });
}



// Remove selected rows and auto-save
ptRemoveSelected.addEventListener("click", () => {
  const rows = [...rowContainer.children];
  rows.forEach(r => {
    if (r.classList.contains("selected-row")) r.remove();
  });
  recomputeTotal();
  window._priceTracker.save(); // auto-save after removal
});


  ptBackBtn.addEventListener("click", () => {
    priceTrackerOverlay.style.display = "none";
    ptBackBtn.style.display = "none";
    const trackerBtn = document.querySelector('button[data-pt-tracker="true"]');
    if (trackerBtn) trackerBtn.style.display = "block";
    const searchContainerEl = document.getElementById("searchContainer");
    if (searchContainerEl) searchContainerEl.style.display = "flex";
  });

  ptSave.addEventListener("click", saveRows);
  ptClear.addEventListener("click", () => { if(confirm("Clear all?")) clearAll(); });

  const trackerBtn = document.createElement("button");
  trackerBtn.textContent = "Price Tracker";
  trackerBtn.dataset.ptTracker = "true";
  trackerBtn.style = `
    background:#4a90e2;color:#fff;font-weight:bold;
    padding:8px 16px;border:none;border-radius:8px;
    cursor:pointer;width:90%;margin:10px auto;display:block;
  `;
  const searchContainer = document.getElementById("searchContainer");
  if(searchContainer) searchContainer.appendChild(trackerBtn); else document.body.appendChild(trackerBtn);

  trackerBtn.addEventListener("click", () => {
    priceTrackerOverlay.style.display = "flex";
    ptBackBtn.style.display = "inline-block";
    trackerBtn.style.display = "none";
    if(searchContainer) searchContainer.style.display = "none";
    loadRows();
  });

  priceTrackerOverlay.style.display = "none";
  ptBackBtn.style.display = "none";

  // selection CSS
  const style = document.createElement("style");
  style.textContent = `
    .selected-row { border-color:#00d9ff !important; background:#00d9ff20 !important; }
  `;
  document.head.appendChild(style);

  // expose API
  window._priceTracker = { save: saveRows, load: loadRows, clear: clearAll, createRow: createRow };
})();







  
// === Prices Overlays for Community and Dejavu ===
const createPricesOverlay = (id, jsonFile, buttonText) => {
  // Overlay container
  const overlay = document.createElement('div');
  overlay.id = id;
  overlay.style = `
    display:none;
    flex-direction:column;
    align-items:flex-start;
    padding:10px;
    background:var(--panel);
    overflow-y:auto;
    border-top:1px solid rgba(0,0,0,0.1);
    width:100%;
    height:450px;
  `;
  document.body.appendChild(overlay);

  // Back button
  const backBtn = document.createElement('button');
  backBtn.textContent = '⬅️ Back';
  backBtn.style = `
    display:none;
    margin-bottom:10px;
    background:#4a90e2;
    color:#fff;
    font-weight:bold;
    padding:6px 12px;
    border:none;
    border-radius:8px;
    cursor:pointer;
  `;
  overlay.appendChild(backBtn);
// =============================
//   INLINE "WHAT'S NEW" BUTTON
// =============================

// Editable text for the developer
const WHATS_NEW_TEXT = `
📢 <b>Latest Updates — 12/6</b>

• Added new <b>What's New</b> button  
• General <b>price list updates</b>  
• Improved overall <b>performance</b>

<b>Price Changes</b>

• <b>Red Tuxedo Pants</b>  
   - <b>Was:</b> 30,000c – 40,000c  
   - <b>Now:</b> <b>40,000c – 50,000c</b>

• <b>Cactus Head</b>  
   - <b>Was:</b> 20,000c – 25,000c  
   - <b>Now:</b> <b>27,000c – 32,000c</b>

• <b>Starry Scarf</b>  
   - <b>Was:</b> 27,500c – 32,500c  
   - <b>Now:</b> <b>35,000c – 45,000c</b>

• <b>Safari Pants</b>  
   - <b>Was:</b> 4,000c – 6,000c  
   - <b>Now:</b> <b>9,000c – 12,000c</b>

• <b>Safari Shirt</b>  
   - <b>Was:</b> 4,000c – 6,000c  
   - <b>Now:</b> <b>9,000c – 12,000c</b>
`.trim();





// Container to place Back + What's New inline
const topRow = document.createElement("div");
topRow.style = `
  width:100%;
  display:flex;
  gap:6px;
  margin-bottom:10px;
`;
overlay.appendChild(topRow);

// Move existing backBtn into this new inline row
backBtn.style.marginBottom = "0"; // remove old margin
topRow.appendChild(backBtn);

// Create small What’s New button
const whatsNewBtn = document.createElement("button");
whatsNewBtn.textContent = "What's New";
whatsNewBtn.style = `
  background:#e0a800;
  color:#fff;
  font-weight:bold;
  padding:6px 12px;
  border:none;
  border-radius:8px;
  cursor:pointer;
`;
topRow.appendChild(whatsNewBtn);

// What’s New overlay page
const whatsNewOverlay = document.createElement("div");
whatsNewOverlay.style = `
  display:none;
  flex-direction:column;
  padding:10px;
  background:var(--panel);
  width:100%;
  height:450px;
  overflow-y:auto;
  border-top:1px solid rgba(0,0,0,0.1);
`;
overlay.appendChild(whatsNewOverlay);

// Back button for What's New page
const whatsNewBack = document.createElement("button");
whatsNewBack.textContent = "⬅️ Back";
whatsNewBack.style = `
    background: rgb(74, 144, 226);
    color: rgb(255, 255, 255);
    font-weight: bold;
    padding: 6px 12px;
    font-size: 12px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    margin-bottom: 10px;
    width: fit-content;
    display: inline-block;
    white-space: nowrap;
`;
whatsNewOverlay.appendChild(whatsNewBack);


// What's New content
const whatsNewContent = document.createElement("div");
whatsNewContent.innerHTML = `
  <pre style="white-space:pre-wrap;font-size:14px;font-family:Arial;padding:5px;">
${WHATS_NEW_TEXT}
  </pre>
`;
whatsNewOverlay.appendChild(whatsNewContent);

// Open What's New page
whatsNewBtn.addEventListener("click", () => {
  whatsNewOverlay.style.display = "flex";
  backBtn.style.display = "none";
  searchInput.style.display = "none";
  results.style.display = "none";
  whatsNewBtn.style.display = "none";
});

// Close What's New page
whatsNewBack.addEventListener("click", () => {
  whatsNewOverlay.style.display = "none";
  backBtn.style.display = "inline-block";
  searchInput.style.display = "block";
  results.style.display = "block";
  whatsNewBtn.style.display = "inline-block";
});

  // Search input
  const searchInput = document.createElement('input');
  searchInput.placeholder = `Search ${buttonText}...`;
  searchInput.style = 'padding:6px 8px;width:95%;margin-bottom:8px;border:2px solid var(--muted);border-radius:6px;font-weight:bold;';
  overlay.appendChild(searchInput);

  // Results list
  const results = document.createElement('ul');
  results.style = 'list-style:none;padding:0;margin:0;width:100%;';
  overlay.appendChild(results);

  // Load JSON data
  let data = [];
  fetch(jsonFile).then(r => r.json()).then(d => { data = d; renderResults(); });

// Build a single price item
const buildPriceItem = (item, query='') => {
  const li = document.createElement('li');
  li.className = 'resultItem';

  // Join all words into a single string for display/search
  const itemText = Array.isArray(item.words) ? item.words.join(' | ') : String(item);

  const re = new RegExp(escapeRegExp(query), 'ig');
  li.innerHTML = query ? itemText.replace(re, m => `<mark>${m}</mark>`) : itemText;
  return li;
};

const renderResults = (query = '') => {
  results.innerHTML = '';
  const q = query.trim().toLowerCase();

  // Filter items based on any word in the "words" array
  const filtered = data.filter(item =>
    Array.isArray(item.words) &&
    item.words.some(w => w.toLowerCase().includes(q))
  );

  if (filtered.length === 0) {
    results.innerHTML = '<li style="padding:8px;">No items found.</li>';
  } else {
    filtered.forEach(item => results.appendChild(buildPriceItem(item, q)));
  }

  // Dynamically adjust overlay height based on results
  adjustOverlayHeight(overlay, results);
};




  // Create toggle button
  const toggleBtn = document.createElement('button');
  toggleBtn.textContent = buttonText;
  toggleBtn.style = 'background:#4a90e2;color:#fff;font-weight:bold;padding:8px 16px;border:none;border-radius:8px;cursor:pointer;width:90%;margin:10px auto;display:block;';
  document.getElementById('searchContainer').appendChild(toggleBtn);

  // Show overlay
  toggleBtn.addEventListener('click', () => {
    overlay.style.display = 'flex';
    backBtn.style.display = 'inline-block';
    toggleBtn.style.display = 'none';
    searchContainer.style.display = 'none';
    renderResults();
  });

  // Hide overlay
  backBtn.addEventListener('click', () => {
    overlay.style.display = 'none';
    backBtn.style.display = 'none';
    toggleBtn.style.display = 'inline-block';
    searchContainer.style.display = 'flex';
  });

  searchInput.addEventListener('input', e => renderResults(e.target.value));
};

// Create both overlays
createPricesOverlay('communityOverlay', 'Community_prices.json', 'Community Prices');
createPricesOverlay('dejavuOverlay', 'Dejavu_prices.json', 'Dejavu Prices');


  
// Tools overlay elements
const toolsOverlay = document.getElementById('toolsOverlay');
const toolsResults = document.getElementById('toolsResults');
const toolsToggleBtn = document.getElementById('toolsToggleBtn');
const toolsBackBtn = document.getElementById('toolsBackBtn');
const toolsSearch = document.getElementById('toolsSearch');

// Build a list item for Tools recipes
const buildToolsItem = (recipe, highlightText) => {
  const li = document.createElement('li');
  li.className = 'resultItem';

  const nameWrap = document.createElement('div');
  nameWrap.className = 'recipeName';
  const re = new RegExp(escapeRegExp(highlightText || ''), 'ig');
  nameWrap.innerHTML = highlightText
    ? recipe.name.replace(re, m => `<mark>${m}</mark>`)
    : recipe.name;

  const star = document.createElement('button');
  star.className = 'starBtn';
  if (favorites.includes(recipe.name)) star.classList.add('active');
  star.innerHTML = '★';
  star.addEventListener('click', e => {
    e.stopPropagation();
    const idx = favorites.indexOf(recipe.name);
    if (idx === -1) {
      favorites.push(recipe.name);
      star.classList.add('active');
    } else {
      favorites.splice(idx, 1);
      star.classList.remove('active');
    }
    saveFavorites();
  });

  li.append(nameWrap, star);
  li.addEventListener('click', () => openRecipe(recipe));
  return li;
};

// Render Tools recipes
const renderToolsResults = (query = '') => {
  toolsResults.innerHTML = '';
  const q = query.trim().toLowerCase();

  // Filter recipes with 'Tools' category
  const list = recipes.filter(r => r.categories && r.categories.some(c => c.toLowerCase() === 'tools'));
  const filtered = q ? list.filter(r => r.name.toLowerCase().includes(q)) : list;

  if (filtered.length === 0) {
    toolsResults.innerHTML = '<li style="padding:8px;">No Tools recipes found.</li>';
  } else {
    filtered.forEach(r => toolsResults.appendChild(buildToolsItem(r, q)));
  }
};

// Hide by default
toolsToggleBtn.style.display = 'none';

// Show only on home page
if (window.location.pathname === '/' || window.location.pathname.endsWith('index.html')) {
  toolsToggleBtn.style.display = 'none';

  toolsToggleBtn.addEventListener('click', () => {
    toolsOverlay.style.display = 'flex';
    toolsToggleBtn.style.display = 'none';
    toolsBackBtn.style.display = 'none';
    searchContainer.style.display = 'none';
    minesOverlay.style.display = 'none';
    renderToolsResults();
    document.body.style.height = '500px';
  });

  toolsBackBtn.addEventListener('click', () => {
    toolsOverlay.style.display = 'none';
    toolsBackBtn.style.display = 'none';
    toolsToggleBtn.style.display = 'none';
    searchContainer.style.display = 'flex';
    document.body.style.height = '250px';
  });

  toolsSearch.addEventListener('input', e => renderToolsResults(e.target.value));
}





  // Mines elements
  const minesOverlay = document.getElementById('minesOverlay');
  const minesContent = document.getElementById('minesContent');
  const mineToggleBtn = document.getElementById('mineToggleBtn'); 
  const mineBackBtn = document.getElementById('mineBackBtn');

  const storageAvailable = typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;
  const storageGet = async (key) => storageAvailable
    ? new Promise(r => chrome.storage.local.get(key, res => r(res[key])))
    : JSON.parse(localStorage.getItem(key) || 'null');
  const storageSet = async (key, value) => storageAvailable
    ? new Promise(r => chrome.storage.local.set({ [key]: value }, r))
    : localStorage.setItem(key, JSON.stringify(value));

  let favorites = await storageGet('favorites') || [];
  let recent = await storageGet('recent') || [];
  let theme = await storageGet('theme') || 'light';
  let currentRecipe = null, currentLinkIndex = 0;

  document.documentElement.setAttribute('data-theme', theme);
  themeBtn.textContent = theme === 'dark' ? '🌙' : '🌓';

  const saveFavorites = () => storageSet('favorites', favorites);
  const saveRecent = () => storageSet('recent', recent);
  const saveTheme = () => storageSet('theme', theme);

  const escapeRegExp = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  const buildItem = (recipe, highlightText) => {
    const li = document.createElement('li');
    li.className = 'resultItem';
    const nameWrap = document.createElement('div');
    nameWrap.className = 'recipeName';
    const re = new RegExp(escapeRegExp(highlightText || ''), 'ig');
    nameWrap.innerHTML = highlightText
      ? recipe.name.replace(re, m => `<mark>${m}</mark>`)
      : recipe.name;

    const star = document.createElement('button');
    star.className = 'starBtn';
    if (favorites.includes(recipe.name)) star.classList.add('active');
    star.innerHTML = '★';
    star.addEventListener('click', e => {
      e.stopPropagation();
      const idx = favorites.indexOf(recipe.name);
      if (idx === -1) {
        favorites.push(recipe.name);
        star.classList.add('active');
      } else {
        favorites.splice(idx, 1);
        star.classList.remove('active');
      }
      saveFavorites();
    });

    li.append(nameWrap, star);
    li.addEventListener('click', () => openRecipe(recipe));
    return li;
  };

  const renderResults = (query = '', focusSection = null) => {
    results.innerHTML = '';
    const q = query.trim().toLowerCase();
    let list = recipes;

    if (focusSection === 'favorites') {
      list = recipes.filter(r => favorites.includes(r.name));
    } else if (focusSection === 'recent') {
      list = recipes.filter(r => recent.includes(r.name));
    } else if (q) {
      list = recipes.filter(r => r.name.toLowerCase().includes(q));

    }

    if (list.length === 0) {
      results.classList.remove('show');
      results.style.display = 'none';
      document.body.style.height = `${INITIAL_SEARCH_HEIGHT}px`;
      return;
    }

    list.forEach(r => results.appendChild(buildItem(r, q)));
    results.classList.add('show');
    results.style.display = 'block';
    const totalRows = results.querySelectorAll('li.resultItem').length;
    document.body.style.height = `${Math.min(ROW_HEIGHT * totalRows + 150, 475)}px`;
  };

const openRecipe = recipe => {
  currentRecipe = recipe;
  
  // Try to find the wiki link first
  const wikiLink = recipe.links.find(link => link.includes('fandom.com/wiki'));
  
  // Default to the first link if no wiki link exists
  frame.src = wikiLink || recipe.links[0] || '';
  
  currentLinkIndex = 0; // start at first link
  viewer.style.display = 'flex';       // Show full-page viewer
  viewerBtns.style.display = 'flex';   // Show back/toggle buttons
  searchContainer.style.display = 'none';
  minesOverlay.style.display = 'none';
  toolsOverlay.style.display = 'none';

  // Save recent
  recent = [recipe.name, ...recent.filter(n => n !== recipe.name)].slice(0, 5);
  saveRecent();

  document.body.style.height = '100vh'; // Optional, forces full-page
};



 backBtn.addEventListener('click', () => {
  viewer.style.display = 'none';
  viewerBtns.style.display = 'none';
  searchContainer.style.display = 'flex';
  toolsToggleBtn.style.display = 'none';
  mineToggleBtn.style.display = 'none';
  document.body.style.height = '250px'; // Reset page height
});



  themeBtn.addEventListener('click', () => {
    theme = theme === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', theme);
    themeBtn.textContent = theme === 'dark' ? '🌙' : '🌓';
    saveTheme();
  });

  favListBtn.addEventListener('click', () => renderResults('', 'favorites'));
  recentBtn.addEventListener('click', () => renderResults('', 'recent'));
  searchInput.addEventListener('input', e => renderResults(e.target.value));

  // ✅ Toggle link button
  toggleBtn.addEventListener('click', () => {
    if (!currentRecipe) return;
    currentLinkIndex = (currentLinkIndex + 1) % currentRecipe.links.length;
    frame.src = currentRecipe.links[currentLinkIndex];
  });

  // ✅ Mines overlay
  const mineData = {
    "Tropical Mine": ["Tropical Grass", "Mountain", "Sand", "Half Sand", "Water", "Coral", "Lava", "Soil", "Dirt", "Ruby", "Rubber Tree", "Palm Tree", "Cotton Bush", "Bush", "Fairy Dust", "Flowers"],
    "Forest Mine": ["Grass", "Water", "Mud", "Dirt", "Tree", "Sunberry Bushes", "Bushes", "Lily pad", "Flowers", "Stone", "Coal", "Iron", "Silver", "Beeswax", "Honey", "Fairy Dust", "Gold"],
    "Desert Mine": ["Boulder", "Mesa Top", "Mesa", "Water", "Mud", "Sand", "Dirt", "Cactus", "Palm Tree", "Chiliberry Bush", "Egg", "Stone", "Gold", "Silver", "Iron", "Coal", "Bone", "Sticks"],
    "Mountain Mine": ["Snow", "Mountain Boulder", "Ice", "Mountain", "Mountain Grass", "Cave Wall", "Pine Tree", "Yumberry Bush", "Egg", "Stone", "Coal", "Iron", "Silver", "Beeswax", "Honey", "Gold", "Sticks"],
    "Arctic Mine": ["Ice Boulder", "Mountain Boulder", "Snow", "Oil", "Mountain", "Mountain Grass", "Ice", "Dirt", "Dead Tree", "Snowy Pine Tree", "Frostberrie", "Fast Geyser", "Slow Geyser", "Coal", "Iron", "Silver", "Gold", "Sticks"]
  };

  // Mines overlay
mineToggleBtn.addEventListener('click', () => {
  minesContent.innerHTML = '';

  Object.entries(mineData).forEach(([mineName, items]) => {
    const header = document.createElement('div');
    header.className = 'sectionHeader';
    header.textContent = mineName;

    const ul = document.createElement('ul');
    ul.style.display = 'none';
    ul.style.listStyle = 'none';
    ul.style.paddingLeft = '10px';

    // ✅ Make each mine item clickable
    items.forEach(itemName => {
      const li = document.createElement('li');
      li.textContent = itemName;
      li.className = 'resultItem';

      li.addEventListener('click', () => {
        const cleanName = itemName.replace(/\*$/, '').trim(); // remove trailing * if any
        const recipe = recipes.find(r => r.name.toLowerCase() === cleanName.toLowerCase());
        if (recipe) {
          minesOverlay.style.display = 'none';
          mineBackBtn.style.display = 'none';
          openRecipe(recipe);
        } else {
          console.warn(`Recipe not found: "${cleanName}"`);
        }
      });

      ul.appendChild(li);
    });

    header.addEventListener('click', () => {
      ul.style.display = ul.style.display === 'none' ? 'block' : 'none';
    });

    minesContent.appendChild(header);
    minesContent.appendChild(ul);
  });

  // Show overlay
  minesOverlay.style.display = 'flex';
  mineToggleBtn.style.display = 'none';
  mineBackBtn.style.display = 'inline-block';
  searchInput.style.display = 'none';
  results.style.display = 'none';
  document.body.style.height = '450px';
});


mineBackBtn.addEventListener('click', () => {
  minesOverlay.style.display = 'none';
  mineBackBtn.style.display = 'none';
  mineToggleBtn.style.display = 'inline-block';
  searchInput.style.display = 'block';
  results.style.display = 'block';
  document.body.style.height = '250px'; // match new default
});

// Show Mines overlay
mineToggleBtn.addEventListener('click', () => {
  minesContent.innerHTML = '';

  Object.entries(mineData).forEach(([mineName, items]) => {
    const header = document.createElement('div');
    header.className = 'sectionHeader';
    header.textContent = mineName;

    const ul = document.createElement('ul');
    ul.style.display = 'none';
    ul.style.listStyle = 'none';
    ul.style.paddingLeft = '10px';

    items.forEach(itemName => {
      const li = document.createElement('li');
      li.textContent = itemName;
      li.className = 'resultItem';

      li.addEventListener('click', () => {
        const cleanName = itemName.replace(/\*$/, '').trim();
        const recipe = recipes.find(r => r.name.toLowerCase() === cleanName.toLowerCase());
        if (recipe) {
          minesOverlay.style.display = 'none';
          mineOverlayBackBtn.style.display = 'none';
          openRecipe(recipe);
        }
      });

      ul.appendChild(li);
    });

    header.addEventListener('click', () => {
      ul.style.display = ul.style.display === 'none' ? 'block' : 'none';
    });

    minesContent.appendChild(header);
    minesContent.appendChild(ul);
  });

  // Show overlay
  minesOverlay.style.display = 'flex';
  mineToggleBtn.style.display = 'none';
  mineOverlayBackBtn.style.display = 'inline-block';

  toolsOverlay.style.display = 'none';
  toolsToggleBtn.style.display = 'none';
  toolsBackBtn.style.display = 'none';

  searchContainer.style.display = 'none';
  results.style.display = 'none';
  document.body.style.height = '450px';
});

// Hide Mines overlay
mineOverlayBackBtn.addEventListener('click', () => {
  minesOverlay.style.display = 'none';
  mineOverlayBackBtn.style.display = 'none';
  mineToggleBtn.style.display = 'inline-block';

  searchContainer.style.display = 'flex';
  results.style.display = 'block';
  document.body.style.height = '250px';
});



  document.body.style.height = '250px';
});
